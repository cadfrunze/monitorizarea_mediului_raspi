
cred_brut:str = "/home/cadfrunze/projects/post_raspi/cadfrunze-raspi-firebase-adminsdk-fbsvc-c9ccd27771.json"
end_point:str = "QlUajPJNbVJOwwXOtXhI"
url_adrr:str = "https://cadfrunze-raspi-default-rtdb.europe-west1.firebasedatabase.app/"

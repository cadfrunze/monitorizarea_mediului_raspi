obligatoriu
1. venv

2. cadfrunze-raspi-firebase-adminsdk-fbsvc-c9ccd27771.json - autentificare firebase (key)


------------librarii externe------------- laptop

3. dotenv - pt citire variabile din .env


4. firebase-admin - interogare pt ssid si adresa ip de la raspi

5. paramiko - conexiune ssh la raspi

6. flask - server afisare web

7. matplotlib - afisare grafica

8. socket - adresa ip
9. qr-code

------------librarii externe------------- raspi
1. bme680 -senzor integrat Bosch BME680
2. firebase-firebase-admin
3. dotenv